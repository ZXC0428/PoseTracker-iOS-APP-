import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

ExerciseType = Literal["squat", "jumpingJack", "lunge"]
Level = Literal["easy", "medium", "hard"]


class RegisterRequest(BaseModel):
    username: str = Field(min_length=3, max_length=100)
    password: str = Field(min_length=8, max_length=128)


class LoginRequest(RegisterRequest):
    pass


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: uuid.UUID
    username: str


class UserResponse(BaseModel):
    id: uuid.UUID
    username: str
    model_config = ConfigDict(from_attributes=True)


class WorkoutInput(BaseModel):
    id: uuid.UUID
    exercise_type: ExerciseType
    level: Level
    count: int = Field(ge=0)
    is_completed: bool
    timestamp: datetime


class WorkoutSyncRequest(BaseModel):
    records: list[WorkoutInput] = Field(max_length=500)


class WorkoutSyncResponse(BaseModel):
    synced_ids: list[uuid.UUID]


class WorkoutResponse(WorkoutInput):
    pass


class ProgressInput(BaseModel):
    exercise_type: ExerciseType
    highest_unlocked_level: Level


class ProgressResponse(ProgressInput):
    updated_at: datetime
    model_config = ConfigDict(from_attributes=True)

