import uuid
from datetime import datetime, timezone
from typing import Annotated

from fastapi import Depends, FastAPI, HTTPException, status
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .database import check_database_connection, get_db
from .models import User, UserProgress, WorkoutRecord
from .schemas import (
    LoginRequest,
    ProgressInput,
    ProgressResponse,
    RegisterRequest,
    TokenResponse,
    UserResponse,
    WorkoutResponse,
    WorkoutSyncRequest,
    WorkoutSyncResponse,
)
from .security import create_access_token, get_current_user, hash_password, verify_password

app = FastAPI(title="PoseTracker API", version="0.1.0")


@app.get("/health")
def health() -> dict[str, str]:
    check_database_connection()
    return {"status": "ok"}


@app.post("/auth/register", response_model=TokenResponse, status_code=201)
def register(payload: RegisterRequest, db: Annotated[Session, Depends(get_db)]):
    username = payload.username.strip().lower()
    if db.scalar(select(User).where(User.username == username)):
        raise HTTPException(status_code=409, detail="Username already exists")
    now = datetime.now(timezone.utc)
    user = User(
        id=uuid.uuid4(),
        username=username,
        password_hash=hash_password(payload.password),
        created_at=now,
        updated_at=now,
    )
    db.add(user)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="Username already exists")
    db.refresh(user)
    return TokenResponse(
        access_token=create_access_token(user),
        user_id=user.id,
        username=user.username,
    )


@app.post("/auth/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Annotated[Session, Depends(get_db)]):
    username = payload.username.strip().lower()
    user = db.scalar(select(User).where(User.username == username))
    if user is None or not verify_password(payload.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password",
        )
    return TokenResponse(
        access_token=create_access_token(user),
        user_id=user.id,
        username=user.username,
    )


@app.get("/users/me", response_model=UserResponse)
def me(current_user: Annotated[User, Depends(get_current_user)]):
    return current_user


@app.post("/workouts/sync", response_model=WorkoutSyncResponse)
def sync_workouts(
    payload: WorkoutSyncRequest,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[Session, Depends(get_db)],
):
    synced: list[uuid.UUID] = []
    for item in payload.records:
        existing = db.get(WorkoutRecord, item.id)
        if existing is not None:
            if existing.user_id != current_user.id:
                raise HTTPException(status_code=409, detail=f"Record ID conflict: {item.id}")
            synced.append(item.id)
            continue
        db.add(WorkoutRecord(
            id=item.id,
            user_id=current_user.id,
            exercise_type=item.exercise_type,
            level=item.level,
            count=item.count,
            is_completed=item.is_completed,
            workout_timestamp=item.timestamp,
            created_at=datetime.now(timezone.utc),
        ))
        synced.append(item.id)
    db.commit()
    return WorkoutSyncResponse(synced_ids=synced)


@app.get("/workouts", response_model=list[WorkoutResponse])
def list_workouts(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[Session, Depends(get_db)],
):
    records = db.scalars(
        select(WorkoutRecord)
        .where(WorkoutRecord.user_id == current_user.id)
        .order_by(WorkoutRecord.workout_timestamp.desc())
    ).all()
    return [WorkoutResponse(
        id=row.id,
        exercise_type=row.exercise_type,
        level=row.level,
        count=row.count,
        is_completed=row.is_completed,
        timestamp=row.workout_timestamp,
    ) for row in records]


@app.put("/progress", response_model=ProgressResponse)
def update_progress(
    payload: ProgressInput,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[Session, Depends(get_db)],
):
    key = {"user_id": current_user.id, "exercise_type": payload.exercise_type}
    progress = db.get(UserProgress, key)
    now = datetime.now(timezone.utc)
    if progress is None:
        progress = UserProgress(
            **key,
            highest_unlocked_level=payload.highest_unlocked_level,
            updated_at=now,
        )
        db.add(progress)
    else:
        progress.highest_unlocked_level = payload.highest_unlocked_level
        progress.updated_at = now
    db.commit()
    db.refresh(progress)
    return progress


@app.get("/progress", response_model=list[ProgressResponse])
def list_progress(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[Session, Depends(get_db)],
):
    return db.scalars(
        select(UserProgress).where(UserProgress.user_id == current_user.id)
    ).all()

